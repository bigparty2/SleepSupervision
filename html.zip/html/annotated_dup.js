var annotated_dup =
[
    [ "ss", "namespacess.html", [
      [ "discovery", "namespacess_1_1discovery.html", [
        [ "DiscoverySubservice", "classss_1_1discovery_1_1_discovery_subservice.html", "classss_1_1discovery_1_1_discovery_subservice" ]
      ] ],
      [ "interface", "namespacess_1_1interface.html", [
        [ "interfaceManager", "classss_1_1interface_1_1interface_manager.html", "classss_1_1interface_1_1interface_manager" ]
      ] ],
      [ "manager", "namespacess_1_1manager.html", [
        [ "computersManager", "classss_1_1manager_1_1computers_manager.html", "classss_1_1manager_1_1computers_manager" ]
      ] ],
      [ "monitor", "namespacess_1_1monitor.html", [
        [ "MonitorSubservice", "classss_1_1monitor_1_1_monitor_subservice.html", "classss_1_1monitor_1_1_monitor_subservice" ]
      ] ],
      [ "network", "namespacess_1_1network.html", [
        [ "IPV4", "classss_1_1network_1_1_i_p_v4.html", "classss_1_1network_1_1_i_p_v4" ],
        [ "MAC", "classss_1_1network_1_1_m_a_c.html", "classss_1_1network_1_1_m_a_c" ],
        [ "packet", "classss_1_1network_1_1packet.html", "classss_1_1network_1_1packet" ],
        [ "Socket", "classss_1_1network_1_1_socket.html", "classss_1_1network_1_1_socket" ],
        [ "wakeOnLan", "classss_1_1network_1_1wake_on_lan.html", "classss_1_1network_1_1wake_on_lan" ]
      ] ],
      [ "computer", "classss_1_1computer.html", "classss_1_1computer" ],
      [ "coord", "structss_1_1coord.html", "structss_1_1coord" ],
      [ "logger", "classss_1_1logger.html", "classss_1_1logger" ],
      [ "string", "classss_1_1string.html", null ],
      [ "thread", "classss_1_1thread.html", null ]
    ] ]
];