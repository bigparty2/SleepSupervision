var classss_1_1manager_1_1computers_manager =
[
    [ "computersManager", "classss_1_1manager_1_1computers_manager.html#a82e3d258ca4da14d96a48b244105d525", null ],
    [ "~computersManager", "classss_1_1manager_1_1computers_manager.html#a5112026cb94082ef3b67e7b4b04a924a", null ],
    [ "__Insert", "classss_1_1manager_1_1computers_manager.html#a5b120c214d0c245c7a5672bfc9c24f0a", null ],
    [ "Get", "classss_1_1manager_1_1computers_manager.html#a5bd03fee185b2b3de3d8dcab69ad83bf", null ],
    [ "GetHost", "classss_1_1manager_1_1computers_manager.html#a90993fde4d349efdd853734287879bb8", null ],
    [ "HandleRequest", "classss_1_1manager_1_1computers_manager.html#a75beb2787198366f069c344de4299524", null ],
    [ "Insert", "classss_1_1manager_1_1computers_manager.html#ad251c5f092197b81c019a61943b0062b", null ],
    [ "IsHostSeted", "classss_1_1manager_1_1computers_manager.html#a6da8317777988cf7e2eab875408ad500", null ],
    [ "LastUpdate", "classss_1_1manager_1_1computers_manager.html#a15b42f2952053f74e5b1727cff7b93bf", null ],
    [ "Remove", "classss_1_1manager_1_1computers_manager.html#a1849f5f82536e941f84d8bdceadc9b06", null ],
    [ "SetHost", "classss_1_1manager_1_1computers_manager.html#a31358b067e4252e67d59c262b5d78cfb", null ],
    [ "Update", "classss_1_1manager_1_1computers_manager.html#a3e45b3c243d394ae2ed2f702c9694d59", null ],
    [ "thisComputer", "classss_1_1manager_1_1computers_manager.html#afc7e45e3d5a4593545a378f99003397c", null ]
];