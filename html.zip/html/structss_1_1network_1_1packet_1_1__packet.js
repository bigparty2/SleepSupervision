var structss_1_1network_1_1packet_1_1__packet =
[
    [ "ipv4Origin", "structss_1_1network_1_1packet_1_1__packet.html#a51bb57ce3d3c2f04ca0f9d1655c131c7", null ],
    [ "macOrigin", "structss_1_1network_1_1packet_1_1__packet.html#a53a56a8e3e5228498224463cf7046cdb", null ],
    [ "message", "structss_1_1network_1_1packet_1_1__packet.html#a4583827e22d296533126db98b7f9dcdf", null ],
    [ "nameOrigin", "structss_1_1network_1_1packet_1_1__packet.html#abb4c12210622bd4baec1a5aa4c8ac560", null ],
    [ "portOrigin", "structss_1_1network_1_1packet_1_1__packet.html#a90787ea3662bea0ec4e51c08dbea71f0", null ],
    [ "seqNum", "structss_1_1network_1_1packet_1_1__packet.html#ab73ad794dff60151e5be551c7151912b", null ],
    [ "timestamp", "structss_1_1network_1_1packet_1_1__packet.html#af4e080bbac1333bd53765e33e5c1d877", null ]
];