var interface_8hpp =
[
    [ "ss::interface::interfaceManager", "classss_1_1interface_1_1interface_manager.html", "classss_1_1interface_1_1interface_manager" ],
    [ "ss::interface::interfaceManager::terminalSizeManager", "classss_1_1interface_1_1interface_manager_1_1terminal_size_manager.html", "classss_1_1interface_1_1interface_manager_1_1terminal_size_manager" ]
];