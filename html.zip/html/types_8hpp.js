var types_8hpp =
[
    [ "ss::coord", "structss_1_1coord.html", "structss_1_1coord" ],
    [ "byte", "types_8hpp.html#aa2424362468457b3d99350e1108da94b", null ]
];