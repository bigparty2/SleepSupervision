var classss_1_1network_1_1wake_on_lan_1_1magic_packet =
[
    [ "magicPacket", "classss_1_1network_1_1wake_on_lan_1_1magic_packet.html#a565405908219180fe025ba7a0395992a", null ],
    [ "Get", "classss_1_1network_1_1wake_on_lan_1_1magic_packet.html#a2d837cd24a503a903c2782985bb2e41e", null ],
    [ "ToString", "classss_1_1network_1_1wake_on_lan_1_1magic_packet.html#ab0826dcfdc1b62db7662672d840114e5", null ]
];