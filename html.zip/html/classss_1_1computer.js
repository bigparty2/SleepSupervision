var classss_1_1computer =
[
    [ "computerStatus", "classss_1_1computer.html#afefbe53725f340e88d378a284979811f", [
      [ "awake", "classss_1_1computer.html#afefbe53725f340e88d378a284979811fa470995453117c1bb371f441cd92a937c", null ],
      [ "sleep", "classss_1_1computer.html#afefbe53725f340e88d378a284979811fa468a09ec5dad81428e1f76efc2b78820", null ],
      [ "unknown", "classss_1_1computer.html#afefbe53725f340e88d378a284979811fa2febd3bbbe6a38e30a2e16ab402c04b7", null ]
    ] ],
    [ "computer", "classss_1_1computer.html#acedafaed7311af6bc96c2c73fb66bb15", null ],
    [ "computer", "classss_1_1computer.html#ada7e9d59ab167defd80ab1fd318e8d53", null ],
    [ "GetComputerInfo", "classss_1_1computer.html#a2d338a3056cc0975d13693dd67f887ae", null ],
    [ "GetIPV4", "classss_1_1computer.html#a42875fc7e81b5b8f03659526dbf696c2", null ],
    [ "GetMAC", "classss_1_1computer.html#a43e1349e09fe59d8dbd42e70b6c28558", null ],
    [ "GetName", "classss_1_1computer.html#a3f54ce4d75a47c5744247efbe2a6db9a", null ],
    [ "GetStatus", "classss_1_1computer.html#ab50820909e034b074e1f47558fd42e81", null ],
    [ "SetStatus", "classss_1_1computer.html#a543ad2fb940b4dbc6e3c773574037677", null ],
    [ "StatusToStringBR", "classss_1_1computer.html#ac0fe97724865e19744efb395714842ad", null ],
    [ "StatusToStringEN", "classss_1_1computer.html#ad2d01cd1068dc9cafeed82f56ab4d642", null ]
];