var manager_8hpp =
[
    [ "ss::manager::computersManager", "classss_1_1manager_1_1computers_manager.html", "classss_1_1manager_1_1computers_manager" ]
];