var logger_8hpp =
[
    [ "ss::logger", "classss_1_1logger.html", "classss_1_1logger" ]
];