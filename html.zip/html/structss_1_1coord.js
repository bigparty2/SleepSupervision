var structss_1_1coord =
[
    [ "x", "structss_1_1coord.html#a3580448b0316891338d668acb6e7dc2a", null ],
    [ "y", "structss_1_1coord.html#abe0e6ed9252473603650feb270831c29", null ]
];