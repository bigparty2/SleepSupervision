var searchData=
[
  ['send_0',['Send',['../classss_1_1network_1_1_socket.html#aa34c14536a04b731b09f0243da0d6772',1,'ss::network::Socket::Send(const char *data, size_t dataSize, uint16_t port, uint32_t address)'],['../classss_1_1network_1_1_socket.html#ad33b00e446ac26eee6d89e0173ebd801',1,'ss::network::Socket::Send(const char *data, size_t dataSize, uint16_t port, char *address)'],['../classss_1_1network_1_1_socket.html#a471c922d1b5844c804235e169942a623',1,'ss::network::Socket::Send(packet &amp;packet, uint16_t port, uint32_t address)'],['../classss_1_1network_1_1_socket.html#ad804d75ecb64a66a179862a822c41ad1',1,'ss::network::Socket::Send(packet &amp;packet, uint16_t port, char *address)']]],
  ['setcolordefault_1',['SetColorDefault',['../classss_1_1interface_1_1interface_manager.html#a419a790e055759f0636e65fb3a97fd6a',1,'ss::interface::interfaceManager']]],
  ['setconfig_2',['SetConfig',['../classss_1_1network_1_1_socket.html#a8f29ff5856b74a8cf2c351cadb23a237',1,'ss::network::Socket']]],
  ['sethost_3',['SetHost',['../classss_1_1manager_1_1computers_manager.html#a31358b067e4252e67d59c262b5d78cfb',1,'ss::manager::computersManager']]],
  ['setpacket_4',['SetPacket',['../classss_1_1network_1_1packet.html#a21da825c95f129e788a0212c85f25bca',1,'ss::network::packet::SetPacket(computer computer, packetMesg message, uint16_t port, byte seq=1)'],['../classss_1_1network_1_1packet.html#ae1c3524924067e98e160201715dd2bd8',1,'ss::network::packet::SetPacket(_packet packet)']]],
  ['setstatus_5',['SetStatus',['../classss_1_1computer.html#a543ad2fb940b4dbc6e3c773574037677',1,'ss::computer']]],
  ['settextblackbackgroundwrite_6',['SetTextBlackBackgroundWrite',['../classss_1_1interface_1_1interface_manager.html#a2ba67925fc53bdfff3d70c263ca06227',1,'ss::interface::interfaceManager']]],
  ['showcursor_7',['ShowCursor',['../classss_1_1interface_1_1interface_manager.html#a1be501969b3a46f659041bc3ac2e6d4e',1,'ss::interface::interfaceManager']]],
  ['sleep_8',['Sleep',['../classss_1_1thread.html#abe1f1c90410fa9d90b11de6edaf7bfe3',1,'ss::thread']]],
  ['socket_9',['Socket',['../classss_1_1network_1_1_socket.html#a56e5b301f4e1d63e569a6664fa8e35d3',1,'ss::network::Socket']]],
  ['split_10',['Split',['../classss_1_1string.html#a9c6faa7356509dd0ac4c0daa2c66effb',1,'ss::string']]],
  ['start_11',['Start',['../classss_1_1discovery_1_1_discovery_subservice.html#a9c85f5a69e859ed7d7e7980aef626c20',1,'ss::discovery::DiscoverySubservice::Start()'],['../classss_1_1monitor_1_1_monitor_subservice.html#a5b60e8ffbe7d4e272d3b22ac09270d01',1,'ss::monitor::MonitorSubservice::Start()']]],
  ['statustostringbr_12',['StatusToStringBR',['../classss_1_1computer.html#ac0fe97724865e19744efb395714842ad',1,'ss::computer::StatusToStringBR()'],['../classss_1_1computer.html#ae67eeb0ea2c70e93d89c351bd66961f7',1,'ss::computer::StatusToStringBR(computerStatus status)']]],
  ['statustostringen_13',['StatusToStringEN',['../classss_1_1computer.html#ad2d01cd1068dc9cafeed82f56ab4d642',1,'ss::computer::StatusToStringEN()'],['../classss_1_1computer.html#aebaa79a4a0362102c7be23ed018bd767',1,'ss::computer::StatusToStringEN(computerStatus status)']]],
  ['stop_14',['Stop',['../classss_1_1discovery_1_1_discovery_subservice.html#a2335c88f34d50a718f1a1c33443abf09',1,'ss::discovery::DiscoverySubservice::Stop()'],['../classss_1_1monitor_1_1_monitor_subservice.html#a4cfbfa551e801c4a9ef0e9c69a14e5d4',1,'ss::monitor::MonitorSubservice::Stop()']]]
];
