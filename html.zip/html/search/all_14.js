var searchData=
[
  ['x_0',['x',['../structss_1_1coord.html#a3580448b0316891338d668acb6e7dc2a',1,'ss::coord']]]
];
