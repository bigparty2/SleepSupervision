var searchData=
[
  ['macorigin_0',['macOrigin',['../structss_1_1network_1_1packet_1_1__packet.html#a53a56a8e3e5228498224463cf7046cdb',1,'ss::network::packet::_packet']]],
  ['message_1',['message',['../structss_1_1network_1_1packet_1_1__packet.html#a4583827e22d296533126db98b7f9dcdf',1,'ss::network::packet::_packet']]]
];
