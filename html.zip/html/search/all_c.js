var searchData=
[
  ['nameorigin_0',['nameOrigin',['../structss_1_1network_1_1packet_1_1__packet.html#abb4c12210622bd4baec1a5aa4c8ac560',1,'ss::network::packet::_packet']]]
];
