var searchData=
[
  ['computerstatus_0',['computerStatus',['../classss_1_1computer.html#afefbe53725f340e88d378a284979811f',1,'ss::computer']]]
];
