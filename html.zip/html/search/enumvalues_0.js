var searchData=
[
  ['awake_0',['awake',['../classss_1_1computer.html#afefbe53725f340e88d378a284979811fa470995453117c1bb371f441cd92a937c',1,'ss::computer']]]
];
