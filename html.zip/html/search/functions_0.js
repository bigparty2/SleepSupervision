var searchData=
[
  ['_5f_5finsert_0',['__Insert',['../classss_1_1manager_1_1computers_manager.html#a5b120c214d0c245c7a5672bfc9c24f0a',1,'ss::manager::computersManager']]]
];
