var searchData=
[
  ['clear_0',['Clear',['../classss_1_1interface_1_1interface_manager.html#ac148f3f7eda3881f1553fca1468a37f2',1,'ss::interface::interfaceManager']]],
  ['computer_1',['computer',['../classss_1_1computer.html#acedafaed7311af6bc96c2c73fb66bb15',1,'ss::computer::computer()'],['../classss_1_1computer.html#ada7e9d59ab167defd80ab1fd318e8d53',1,'ss::computer::computer(std::string name, network::MAC macAddr, network::IPV4 ipv4, computerStatus status)']]],
  ['computersmanager_2',['computersManager',['../classss_1_1manager_1_1computers_manager.html#a82e3d258ca4da14d96a48b244105d525',1,'ss::manager::computersManager']]]
];
