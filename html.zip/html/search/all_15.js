var searchData=
[
  ['y_0',['y',['../structss_1_1coord.html#abe0e6ed9252473603650feb270831c29',1,'ss::coord']]]
];
