var searchData=
[
  ['awake_0',['Awake',['../classss_1_1network_1_1wake_on_lan.html#a0aeab2e38d3274e233f431a7f5dd327f',1,'ss::network::wakeOnLan']]],
  ['awake_1',['awake',['../classss_1_1computer.html#afefbe53725f340e88d378a284979811fa470995453117c1bb371f441cd92a937c',1,'ss::computer']]]
];
