var searchData=
[
  ['init_0',['Init',['../classss_1_1interface_1_1interface_manager.html#a5a9272e0124b7a9d7c82f5a854650f19',1,'ss::interface::interfaceManager']]],
  ['insert_1',['Insert',['../classss_1_1manager_1_1computers_manager.html#ad251c5f092197b81c019a61943b0062b',1,'ss::manager::computersManager']]],
  ['interfacemanager_2',['interfaceManager',['../classss_1_1interface_1_1interface_manager.html#aeee9eb4aae96239a6d310bbce0998c42',1,'ss::interface::interfaceManager::interfaceManager()'],['../classss_1_1interface_1_1interface_manager.html#ab119e9010e775cc145d0b43bb09dc483',1,'ss::interface::interfaceManager::interfaceManager(ss::manager::computersManager &amp;cm, bool manager)']]],
  ['ipv4_3',['IPV4',['../classss_1_1network_1_1_i_p_v4.html#aeb89123b3b19c11d72bc86bf8badfb56',1,'ss::network::IPV4::IPV4()'],['../classss_1_1network_1_1_i_p_v4.html#a4ce7485ec0b04f4a4c61b5814d04da32',1,'ss::network::IPV4::IPV4(uint32_t addr)'],['../classss_1_1network_1_1_i_p_v4.html#a2c3b03519bf6a5949a85d1589feb7db9',1,'ss::network::IPV4::IPV4(const std::string &amp;addr)']]],
  ['isdatainicialized_4',['IsDataInicialized',['../classss_1_1network_1_1packet.html#a57c2d71aea8f69abb22e0c43376e0714',1,'ss::network::packet']]],
  ['ishostseted_5',['IsHostSeted',['../classss_1_1manager_1_1computers_manager.html#a6da8317777988cf7e2eab875408ad500',1,'ss::manager::computersManager']]]
];
