var searchData=
[
  ['sleep_0',['sleep',['../classss_1_1computer.html#afefbe53725f340e88d378a284979811fa468a09ec5dad81428e1f76efc2b78820',1,'ss::computer']]]
];
