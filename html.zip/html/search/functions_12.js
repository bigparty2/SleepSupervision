var searchData=
[
  ['warning_0',['Warning',['../classss_1_1logger.html#a443d322d51c44bcb5b4ef254d9517c50',1,'ss::logger']]]
];
