var searchData=
[
  ['logger_0',['logger',['../classss_1_1logger.html',1,'ss']]]
];
