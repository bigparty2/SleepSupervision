var searchData=
[
  ['receivepacket_0',['receivePacket',['../classss_1_1network_1_1_socket.html#a71a3d935c3f01defa3732911bbdae72d',1,'ss::network::Socket']]],
  ['regitry_1',['REGITRY',['../classss_1_1network_1_1packet.html#ab26d27c98e617f81c6131567325124fca8e06c9d18de8019fe8dc8a20e9e8e636',1,'ss::network::packet']]],
  ['remove_2',['Remove',['../classss_1_1manager_1_1computers_manager.html#a1849f5f82536e941f84d8bdceadc9b06',1,'ss::manager::computersManager']]],
  ['repeat_3',['Repeat',['../classss_1_1string.html#aadeec2838fc82cb15fdf9e195452ffcb',1,'ss::string']]]
];
