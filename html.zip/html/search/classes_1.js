var searchData=
[
  ['computer_0',['computer',['../classss_1_1computer.html',1,'ss']]],
  ['computersmanager_1',['computersManager',['../classss_1_1manager_1_1computers_manager.html',1,'ss::manager']]],
  ['coord_2',['coord',['../structss_1_1coord.html',1,'ss']]]
];
