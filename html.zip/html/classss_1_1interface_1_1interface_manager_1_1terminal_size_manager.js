var classss_1_1interface_1_1interface_manager_1_1terminal_size_manager =
[
    [ "terminalSizeManager", "classss_1_1interface_1_1interface_manager_1_1terminal_size_manager.html#a70c64b491da827dcfc781efa77bca513", null ],
    [ "~terminalSizeManager", "classss_1_1interface_1_1interface_manager_1_1terminal_size_manager.html#aacc5133cbc09189c38a31e0c11d4b079", null ],
    [ "Get", "classss_1_1interface_1_1interface_manager_1_1terminal_size_manager.html#a6468a7d7f6ce50da5947932f30af797a", null ],
    [ "HasChange", "classss_1_1interface_1_1interface_manager_1_1terminal_size_manager.html#a7e9510eb367736f647fe80faae16bef4", null ]
];