var classss_1_1logger =
[
    [ "Debug", "classss_1_1logger.html#ab04ac127dfed31d9be0dda4136d7892f", null ],
    [ "Error", "classss_1_1logger.html#a3111e139e2a5cd412632e5b8438de1b4", null ],
    [ "Log", "classss_1_1logger.html#a19599a1d87dc61a66a7bec24a38b1952", null ],
    [ "Warning", "classss_1_1logger.html#a443d322d51c44bcb5b4ef254d9517c50", null ]
];