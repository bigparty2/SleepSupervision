var classss_1_1network_1_1wake_on_lan =
[
    [ "magicPacket", "classss_1_1network_1_1wake_on_lan_1_1magic_packet.html", "classss_1_1network_1_1wake_on_lan_1_1magic_packet" ]
];