var computer_8hpp =
[
    [ "ss::computer", "classss_1_1computer.html", "classss_1_1computer" ],
    [ "computers", "computer_8hpp.html#aca5b0110c1b0f884259c8b7d09d6b607", null ]
];