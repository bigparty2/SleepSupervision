var namespacess =
[
    [ "discovery", "namespacess_1_1discovery.html", "namespacess_1_1discovery" ],
    [ "interface", "namespacess_1_1interface.html", "namespacess_1_1interface" ],
    [ "manager", "namespacess_1_1manager.html", "namespacess_1_1manager" ],
    [ "monitor", "namespacess_1_1monitor.html", "namespacess_1_1monitor" ],
    [ "network", "namespacess_1_1network.html", "namespacess_1_1network" ],
    [ "computer", "classss_1_1computer.html", "classss_1_1computer" ],
    [ "coord", "structss_1_1coord.html", "structss_1_1coord" ],
    [ "logger", "classss_1_1logger.html", "classss_1_1logger" ],
    [ "string", "classss_1_1string.html", null ],
    [ "thread", "classss_1_1thread.html", null ],
    [ "byte", "namespacess.html#aa2424362468457b3d99350e1108da94b", null ],
    [ "computers", "namespacess.html#aca5b0110c1b0f884259c8b7d09d6b607", null ]
];